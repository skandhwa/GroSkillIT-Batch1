package StepDefinition;

import org.openqa.selenium.WebDriver;

import PageFactory.NewCustomerCreation;
import PageFactory.NewLatestLoginScenario;
import Utilities.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition extends BaseClass {
	
	   WebDriver driver=BaseClass.initializeDriver();
	   NewLatestLoginScenario obj1=new NewLatestLoginScenario(driver);
	   NewCustomerCreation obj2=new NewCustomerCreation(driver);
	
	
	
	
	@Given("User logins into the demo application")
	public void user_logins_into_the_demo_application() {
		
		System.out.println("Application launched");
	    
	}

	@Given("then user will enter the username as {string}")
	public void then_user_will_enter_the_username_as(String username) {
	    
		obj1.enterUserID(username);
		
	}

	@Given("then user will enters the password as {string}")
	public void then_user_will_enters_the_password_as(String password) {
	   
		obj1.enterPassword(password);
		
	}

	@When("User will clicks on login button")
	public void user_will_clicks_on_login_button() {
		
		obj1.clickOnSubmit();
		
	   
	}

	@Then("User will be navigated to home page of the demo application")
	public void user_will_be_navigated_to_home_page_of_the_demo_application() {
	    
	}
	
	
	@Given("User clicks on New Cutomer creation link")
	public void user_clicks_on_new_cutomer_creation_link() {
	   
		obj2.clickOnNewCustomer();
	}

	@Given("User enters the Customer Name in the field as {string}")
	public void user_enters_the_customer_name_in_the_field_as(String Customer_name) {
	    
		obj2.enterCustomerName(Customer_name);
		
	}

	@Given("User selects the gender")
	public void user_selects_the_gender() {
		
		obj2.clickOnGender();
	   
	}

	@Given("User enters the date of birth of the customer in field as {string}")
	public void user_enters_the_date_of_birth_of_the_customer_in_field_as(String Date_of_birth) {
	    
		obj2.enterDateOfBirth(Date_of_birth);
		
	}

	@Given("User enters the address as {string}")
	public void user_enters_the_address_as(String address) {
		
		obj2.enterAddress(address);
	   
	}
	
	
	@Given("User enters the city name as {string}")
	public void user_enters_the_city_name_as(String city_name) {
	    
		obj2.enterCityName(city_name);
		
	}

	@Given("User enters the state name as {string}")
	public void user_enters_the_state_name_as(String state_name) {
		
		obj2.enterStateName(state_name);
	    
	}



}
