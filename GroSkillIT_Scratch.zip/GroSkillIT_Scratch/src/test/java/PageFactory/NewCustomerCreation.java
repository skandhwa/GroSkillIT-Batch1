package PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class NewCustomerCreation {
	
	WebDriver driver;
	
	public NewCustomerCreation(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
		
	}
	
	@FindBy(xpath="//a[text()='New Customer']")
	WebElement NewCustomerlink;
	
	@FindBy(xpath="//input[@name='name']")
	WebElement Customername;
	
	@FindBy(xpath="//input[@value='m']")
	WebElement Gender;
	
	@FindBy(xpath="//textarea[@name='addr']")
	WebElement Address;
	
	
	@FindBy(xpath="//input[@id='dob']")
	WebElement DOB;
	
	@FindBy(xpath="//input[@name='city']")
	WebElement city;
	
	@FindBy(xpath="//input[@name='state']")
	WebElement State;
	
	
	public void clickOnNewCustomer()
	{
		NewCustomerlink.click();
	}
	
	public void enterCustomerName(String name)
	{
		Customername.sendKeys(name);
	}
	
	public void clickOnGender()
	{
		Gender.click();
	}
	
	public void enterAddress(String address)
	{
		Address.sendKeys(address);
	}
	
	public void enterDateOfBirth(String dateofBirth)
	{
		DOB.sendKeys(dateofBirth);
	}
	
	public void enterCityName(String cityname)
	{
		city.sendKeys(cityname);
	}
	
	public void enterStateName(String statename)
	{
		State.sendKeys(statename);
	}
	
	
	
	
	

}
