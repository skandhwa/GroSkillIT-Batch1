package Constants;

public class constantsData {
	
	public static final String TESTDATAPATH="D:\\TestData18thSeptember.xlsx";
	public static final String PROPERTYFILEPATH ="src/main/java/Global.properties";
	

}
