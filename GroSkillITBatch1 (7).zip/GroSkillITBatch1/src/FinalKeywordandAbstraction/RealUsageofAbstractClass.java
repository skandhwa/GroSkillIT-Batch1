package FinalKeywordandAbstraction;

abstract class Org
{
	void gendetails()
	{
		System.out.println("Employee name");
		System.out.println("Employee gender");
	}
	
	abstract void salary();
	
	void test()
	{
		System.out.println("Hello");
	}
}

class Salary extends Org
{
	void salary()
	{
		System.out.println("salary is there");
	}
	
}
public class RealUsageofAbstractClass {

	public static void main(String[] args) {
		
		Salary obj=new Salary();
		obj.salary();
		obj.test();
		obj.gendetails();
		

	}

}
