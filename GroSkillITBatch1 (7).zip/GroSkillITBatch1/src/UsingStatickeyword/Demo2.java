package UsingStatickeyword;

public class Demo2 {
	
	String display(String x,String y)
	{
		return x+y;
	}
	
	void test(int x,int y)
	{
		int z=x+y;
		System.out.println(z);
	}
	
	static float message(float x,float y)
	{
		return x*y;
	}
	

	public static void main(String[] args) {
		
		Demo2 obj=new Demo2();
	System.out.println(obj.display("harry","jack"));
	
	obj.test(23, 45);
	
	System.out.println(	Demo2.message(12,23));
	
	

	}

}
