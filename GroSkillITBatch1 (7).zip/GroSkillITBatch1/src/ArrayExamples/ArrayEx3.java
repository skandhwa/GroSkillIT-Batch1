package ArrayExamples;

import java.util.Arrays;

public class ArrayEx3 {

	public static void main(String[] args) {
		
		 int []b= {123,166,77,88,99};
		 int []c= {123,987,77,88,99};
		 
	int x=	 Arrays.compare(b, c);
	System.out.println(x);
	
	
	boolean flag=Arrays.equals(b,c);
	System.out.println(flag);
	
	
	Arrays.sort(b);
	
	
		

	}

}
