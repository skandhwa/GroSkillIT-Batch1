package ArrayExamples;

public class ArrayEx2 {

	public static void main(String[] args) {

        int []b= {23,66,77,88,99};
        for(int i=0;i<b.length;i++)///i=0,0<5//i=1,1<5//i=2,2<5....
		{
			System.out.println(b[i]);//a[0]//a[1]//a[2]....a[4]
		}
		
        int x=b.length;
        System.out.println("Length of array is "+x);


		

	}

}
