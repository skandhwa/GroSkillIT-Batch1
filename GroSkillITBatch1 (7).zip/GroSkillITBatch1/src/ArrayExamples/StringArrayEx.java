package ArrayExamples;

public class StringArrayEx {

	public static void main(String[] args) {

          String[]arr= {"Java","Selenium","API"};
          
          for(String x:arr)
          {
        	  System.out.println(x);
          }
		

	}

}
