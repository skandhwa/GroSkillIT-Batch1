package ConstructorinJava;

class Test3
{
	int id;
	String name;
	float salary;
	String address;
	Test3(int i,String n,float s)
	{
		id=i;
		name=n;
		salary=s;
	}
	Test3(int i,String n,float s,String a)
	{
		id=i;
		name=n;
		salary=s;
		address=a;
	}
	
	void display()
	{
		System.out.println(id+" "+name+" "+salary+" "+address );
	}
	
	
	
}
public class ParameterizedConstructorEx {

	public static void main(String[] args) {
		
		Test3 obj=new Test3(1234,"Saurabh",4500f);
		obj.display();
		Test3 obj1=new Test3(1234,"Saurabh",4500f,"Kolkata");
		obj1.display();

	}

}
