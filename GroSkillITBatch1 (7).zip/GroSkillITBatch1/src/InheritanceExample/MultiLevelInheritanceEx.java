package InheritanceExample;
class T8A
	{
		void display()
		{
			System.out.println("hello");
		}
	}

	class T9A extends T8A
	{
		void test()
		{
			System.out.println("Hi");
		}
	}
	
	class T10 extends T9A
	{
		void message()
		{
			System.out.println("Hello how r u");
	     }
	
	}
	public class MultiLevelInheritanceEx {

		public static void main(String[] args) {
			
			T10 obj=new T10();
			obj.message();
			obj.test();
			obj.display();
			
			
			
			
			

		}

	}

	
	
	


