package InheritanceExample;

class Bird
{
	void eat()
	{
		System.out.println("all birds eat");
	}
	void sleep()
	{
		System.out.println("All birds sleep");
	}
	
	
	void features()
	{
		eat();
		sleep();
		 
	}
}


public class CascadedMethods {

	public static void main(String[] args) {
		
		Bird obj=new Bird();
	obj.features();;	
		
		

	}

}
