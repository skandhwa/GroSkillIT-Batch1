package StringExamples;

public class StringExample2 {

	public static void main(String[] args) {
		
		String str="test";
		str.concat("engineer");
		System.out.println(str);
		
		StringBuffer sb=new StringBuffer("hello");
		sb.append("Saurabh");
		System.out.println(sb);
		
		

	}

}
