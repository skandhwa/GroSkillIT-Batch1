package IdeaofEncapsulationandPackages;

public class Test10 {

	public static void main(String[] args) {
		
		Student8 obj=new Student8();
		obj.setName("Mahesh");
		obj.setId(1234);
		
		System.out.println(obj.getName());
		System.out.println(obj.getId());
		

	}

}
