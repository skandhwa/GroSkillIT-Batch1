package MyPractice;

public class LogicalNotOperator {

	public static void main(String[] args) {
		
		int a=5;
		System.out.println(a!=6);
		

	}

}
