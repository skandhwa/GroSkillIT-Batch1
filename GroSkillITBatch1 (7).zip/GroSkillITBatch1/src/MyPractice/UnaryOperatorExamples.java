package MyPractice;

public class UnaryOperatorExamples {

	public static void main(String[] args) {
		
		int a=10;
		int b=5;
		int c=8;
		
		int r= a++ + ++b + c-- + ++a + --c + --b;
		
		//  10 + 6  + 8  + 12  + 6 + 5      ///a=11            //a=12,b=5,c=6
		
		System.out.println(r);

	}

}
