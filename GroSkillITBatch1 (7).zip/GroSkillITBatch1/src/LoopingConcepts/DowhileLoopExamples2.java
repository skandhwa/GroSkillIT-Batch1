package LoopingConcepts;

public class DowhileLoopExamples2 {

	public static void main(String[] args) {
		
		int x=1,sum=0;
	do
		{
			sum=sum+x;  ///sum=0+1 //sum=  1+2=3  //sum=3+3=6 //sum=6+4=10//sum=10+5
			x++; //1++ //2++ //3++ //4++ //5++
			
		}
		while(x<=5);///2<=5 //3<=5  //4<=5 //5<=5  //6<=5
		
		System.out.println("sum is "+sum);
		

	}

}
