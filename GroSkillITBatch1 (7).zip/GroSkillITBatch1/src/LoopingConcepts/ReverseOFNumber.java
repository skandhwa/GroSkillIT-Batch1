package LoopingConcepts;

public class ReverseOFNumber {

	public static void main(String[] args) {
		
		int num=921;
		int n=num;
		int rev=0;
		
		while(num!=0)//123!=0//12!=0 /// 1!=0 //0!=0
			
		{
			int rem=num%10;//rem=123%10=3  // rem=12%10=2 // rem=1%10=1
			rev=rev*10+rem;//rev=0*10+3=3  //rev= 3*10+2=32 //rev=32*10+1=321
			num=num/10;//num=123/10=12  ///num=12/10=1//num=1/0=0
		}
		
		System.out.println("Reverse of number is "+rev);
		
		if(n==rev)
		{
			System.out.println("The number is palindrome");
		}
		else
		{
			System.out.println("The number is not palindrome");
		}

	}

}
