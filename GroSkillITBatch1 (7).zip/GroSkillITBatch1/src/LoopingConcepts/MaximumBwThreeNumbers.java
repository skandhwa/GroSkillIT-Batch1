package LoopingConcepts;

public class MaximumBwThreeNumbers {

	public static void main(String[] args) {
		
		int a=20;
		int b=40;
		int c=125;
		
		if(a>b)//20>40
		{
			if(a>c)
			{
				System.out.println("a is maximum");
			}
			else
			{
				System.out.println("c is maximum");
			}
		}
		
		else
		{
			if(b>c)//
			{
				System.out.println("b is maximum");
			}
			else
			{
				System.out.println("c is maximum");
			}
		}
		
	}

}
