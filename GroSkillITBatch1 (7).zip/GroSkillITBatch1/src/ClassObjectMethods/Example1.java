package ClassObjectMethods;

class Example2
{
	void display()
	{
		System.out.println("hello");
	}

}

class Example3
{
	void test()
	{
		System.out.println("Hi team");
	}
}

public class Example1 {

	public static void main(String[] args) {
		
		
		Example2 obj=new Example2();
		obj.display();

		Example3 obj1=new Example3();
		obj1.test();
	}

}
