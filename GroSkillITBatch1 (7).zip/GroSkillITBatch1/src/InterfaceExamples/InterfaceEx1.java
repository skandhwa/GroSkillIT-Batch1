package InterfaceExamples;

interface If1
{
	int x=10;
	void display();
	void test();
	
}

class C1 implements  If1
{
	public void display()
	{
		System.out.println("hello");
	}
	
	public void test()
	{
		System.out.println("hi");
	}
}

public class InterfaceEx1 {

	public static void main(String[] args) {
		
		C1 obj=new C1();
		obj.display();
		obj.test();
		
		If1 ref=new C1();
		ref.display();
		ref.test();
		
		

	}

}
