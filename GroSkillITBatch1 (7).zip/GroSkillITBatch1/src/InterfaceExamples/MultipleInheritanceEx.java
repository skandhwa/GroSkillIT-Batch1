package InterfaceExamples;

interface Demo2
{
	void display();
	
}
interface Demo4
{
	void test();
	
}

class Demo3 implements Demo2,Demo4
{
	public void display()
	{
		System.out.println("hello");
	}
	public void test()
	{
		System.out.println("hi");
	}
}

public class MultipleInheritanceEx {

	public static void main(String[] args) {
		
		Demo3 obj=new Demo3();
		obj.display();
		obj.test();
		
		
		Demo2 ref=new Demo3();
		ref.display();
		
		Demo4 ref1=new Demo3();
		ref1.test();
		
		

	}

}
