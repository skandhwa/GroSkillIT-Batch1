package InterfaceExamples;

interface If9
{
	int add(int x,int y);
	String display(String k,String l);
	
}

class C10 implements If9
{
	public int add(int p,int q)
	{
		return p+q;
	}
	
	public String display(String m,String n)
	{
		return m+n;
	}
	
	
}

public class IterfaceExample3 {

	public static void main(String[] args) {
		
		If9 ref=new C10();
	System.out.println(ref.add(12, 40));	
	System.out.println(ref.display("India", "Republic"));		

	}

}
