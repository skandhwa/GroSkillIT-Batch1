package InterfaceExamples;

interface If3
{
	 void display();
	 void test();
}

interface If4 extends If3
{
	void message();
	void test2();
}

//interface If5 implements If4
//{
//	
//}

class C9 implements If4
{

	
	public void display() {
		
		System.out.println("Hello");
		
	}

	
	public void test() {
		
		System.out.println("Hi");
	}

	
	public void message() {
	
		System.out.println("Hello how r u");
	}

	
	public void test2() {
		
		System.out.println("Hi how r u");
		
	}
	
}
public class InterfaceExetndsExample {

	public static void main(String[] args) {
		
		If4 ref=new C9();
		ref.test();
		ref.test2();
		ref.display();
		ref.message();
		

	}

}
