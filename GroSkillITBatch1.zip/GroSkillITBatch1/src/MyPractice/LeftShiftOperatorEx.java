package MyPractice;

public class LeftShiftOperatorEx {

	public static void main(String[] args) {
		
		int a=12;
		System.out.println(a<<3);//10*2pow4
		
		
		int b=400;
		System.out.println(b>>6);//400/64
		

	}

}
