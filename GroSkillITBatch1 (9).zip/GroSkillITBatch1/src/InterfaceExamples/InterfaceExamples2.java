package InterfaceExamples;

interface If2 
{
	void test();
	void display();
}

class C7 implements If2
{
	public void test()
	{
	  System.out.println("hello");	
	}
	
	public void display()
	{
		System.out.println("hi");	
	}
}

class C8 implements If2
{

	
	public void test() {
		
		System.out.println("hello am new 2");	
		
	}

	
	public void display() {
		System.out.println("hi I am new 2");	
		
	}
	
}
public class InterfaceExamples2 {

	public static void main(String[] args) {
		
		C7 obj=new C7();
		obj.test();
		obj.display();
		
		C8 obj1=new C8();
		obj1.test();
		obj1.display();
		
		
		If2 ref1=new C7();
		ref1.test();
		ref1.display();
		
		If2 ref2=new C8();
		ref2.test();
		ref2.display();


	}

}
