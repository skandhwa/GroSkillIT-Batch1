package IdeaOnCollections;

import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

public class VectorExample {

	public static void main(String[] args) {
		
		
List<Integer> v=new Vector<Integer>();
		
		v.add(34);
		v.add(56);
		v.add(314);
		v.add(156);
		
		for(Integer x:v)
		{
			System.out.println(x);
		}

	}

}
