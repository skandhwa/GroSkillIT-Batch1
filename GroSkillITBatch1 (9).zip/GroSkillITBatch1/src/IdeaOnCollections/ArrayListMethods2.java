package IdeaOnCollections;

import java.util.ArrayList;
import java.util.List;

public class ArrayListMethods2 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("melon");
		li.add("guava");
		li.add("banana");
		li.add("apple");
		li.add("papaya");
		
		
		
		List<String> li2=new ArrayList<String>();
		li2.add("kiwi");
		li2.add("mango");
		li2.add("apple");
		li2.add("orange");
		li2.add("banana");
		
		
		li2.removeAll(li);
		
		//li2.remove(0);
		
		for(String x:li2)
		{
			System.out.println(x);
		}
		

	}

}
