package PoylMorphismConcepts;

class Employee3
{
	static int add(int x,int y)
	{
		return x+y;
	}
	static float add(int x,float y)
	{
		return x+y;
	}
	
	static long add(int x,int y,int z)
	{
		return x+y+z;
	}
}

public class MethodOverloadingEx2 {

	public static void main(String[] args) {
		
	System.out.println(Employee3.add(5,7));	
	System.out.println(Employee3.add(5,7,12));	
	System.out.println(Employee3.add(5,7.5f));	
		

	}

}
