package Variables;

class A1
{
	
	int h=50;
	void  test()
	{
		int a=10;
		int b=20;
		int c=a+b+h;
		System.out.println("The sum is "+c);
	}
	
	void display()
	{
		int e=30;
		int f=60;
		int g=f-e+h;
		System.out.println("the difference is "+g);
		
		
	}
	
	
}

public class LocalVariables {

	public static void main(String[] args) {
		

	}

}
