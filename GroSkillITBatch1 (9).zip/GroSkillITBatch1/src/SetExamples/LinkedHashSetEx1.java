package SetExamples;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetEx1 {

	public static void main(String[] args) {
		
		Set<String> s1=new LinkedHashSet<String>();
		s1.add("kiwi");
		s1.add("orange");
		s1.add("apple");
		s1.add("grapes");
		
		
		Iterator itr=s1.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		

	}

}
