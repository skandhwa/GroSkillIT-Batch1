package SetExamples;

import java.util.TreeSet;

public class TreeSetEx3 {

	public static void main(String[] args) {
		
		TreeSet<String> t1=new TreeSet<String>();
		
		t1.add("A");
		t1.add("B");
		t1.add("C");
		t1.add("D");
		t1.add("E");
		
		System.out.println(t1);
		
		System.out.println("Reverse set is "+t1.descendingSet());
		
		System.out.println("Head Set "+t1.headSet("C",true));
		
		System.out.println("Tail Set "+t1.tailSet("C",false));
		
		System.out.println("Sub set is "+t1.subSet("A","E"));
		

	}

}
