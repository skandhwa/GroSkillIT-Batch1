package SetExamples;

import java.util.HashSet;
import java.util.Set;

public class HashSetMthods4 {

	public static void main(String[] args) {
		
		Set<String> s1=new HashSet<String>();
		s1.add("kiwi");
		s1.add("Orange");
		s1.add("apple");
		s1.add("grapes");
		
		Set<String> s2=new HashSet<String>();
		s2.add("kiwi");
		s2.add("Orange");
		
	boolean flg=	s1.containsAll(s2);
	System.out.println(flg);
	
	
	
		

	}

}
