package FinalKeywordandAbstraction;

class Test4
{
	final int speed=120;
	void run()
	{
		//speed=200;
		System.out.println(speed);
	}
	
}
public class UsingFinalKeywordforVariable {
	
	public static void main(String[] args)
	{
	
	
	Test4 obj=new Test4();
	obj.run();
	

}
}
