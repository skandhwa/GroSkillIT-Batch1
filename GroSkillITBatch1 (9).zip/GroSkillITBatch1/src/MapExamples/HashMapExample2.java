package MapExamples;

import java.util.HashMap;
import java.util.Map;

public class HashMapExample2 {

	public static void main(String[] args) {
		
		Map<String,String> mp=new HashMap<String,String>();
		
		mp.put("Ramesh", "Cricket");
		mp.put("Mahesh", "Hockey");
		mp.put("Suresh", "Football");
		mp.put("Harsh", "Polo");
		mp.put("Girish", "Swimming");
		
	for(Map.Entry m: mp.entrySet())
	{
		System.out.print(m.getKey()+" ");
		System.out.println(m.getValue());
	}
		

	}

}
