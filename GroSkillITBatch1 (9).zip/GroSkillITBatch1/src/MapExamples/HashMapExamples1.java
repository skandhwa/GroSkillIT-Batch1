package MapExamples;

import java.util.HashMap;
import java.util.Map;

public class HashMapExamples1 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		mp.put(2,"Saurabh");
		mp.put(12,"Gaurabh");
		mp.put(22,"Mohan");
		mp.put(32,null);
		mp.put(42,null);
		mp.put(12,"Harish");
		mp.put(null,"Kamal");
		mp.put(null,"Ramesh");
		
		System.out.println(mp);
		
		
		
		

	}

}
