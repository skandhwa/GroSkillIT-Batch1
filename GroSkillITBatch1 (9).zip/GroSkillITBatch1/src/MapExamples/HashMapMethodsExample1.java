package MapExamples;

import java.util.HashMap;
import java.util.Map;

public class HashMapMethodsExample1 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		mp.put(2,"Saurabh");
		mp.put(12,"Gaurabh");
		mp.put(22,"Mohan");
		mp.put(32,"Harish");
		mp.put(42,"Girish");
		
		
		
		System.out.println(mp);
		
		boolean flag1=	mp.isEmpty();
		System.out.println("Is the map empty "+flag1);
		
		mp.remove(12);
		System.out.println("After removing element ,map elements are");
		System.out.println(mp);
		
		mp.remove(22,"Mohan");
		System.out.println("After removing element ,map elements are");
		System.out.println(mp);
		
		mp.replace(32, "Sohan");
		System.out.println("After replacing element ,map elements are");
		System.out.println(mp);
		
		mp.clear();
		System.out.println("After clearing element ,map elements are");
		System.out.println(mp);
		
	boolean flag=	mp.isEmpty();
	System.out.println(flag);
		
		

	}

}
