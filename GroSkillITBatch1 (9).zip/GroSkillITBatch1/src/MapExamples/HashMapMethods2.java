package MapExamples;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class HashMapMethods2 {

	public static void main(String[] args) {
		
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		mp.put(2,"Saurabh");
		mp.put(12,"Gaurabh");
		mp.put(22,"Mohan");
		mp.put(32,"Harish");
		mp.put(42,"Girish");
		
		Map<Integer,String> mp1=new HashMap<Integer,String>();
		mp1.put(2,"Mahesh");
		mp1.put(52,"Ramesh");
		mp1.put(62,"Garima");
		
		mp.putAll(mp1);
		
		System.out.println(mp);
		
		
	boolean flag=	mp.containsKey(22);
	System.out.println("Does the map contains 22 "+flag);
	
	boolean flag1=	mp.containsKey(92);
	System.out.println("Does the map contains 92 "+flag1);
	
	boolean flag2=	mp.containsValue("Rohit");
	System.out.println("Does the map contains Rohit "+flag2);
	
	String value=mp.get(42);
	System.out.println("Value at key 42 is  "+value);
	
Set<Integer> s1=	mp.keySet();

System.out.println("The Keys of set are "+s1);
	
		
		
		
		

	}

}
