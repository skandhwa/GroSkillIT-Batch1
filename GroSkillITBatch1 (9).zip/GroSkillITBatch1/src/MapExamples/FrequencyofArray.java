package MapExamples;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyofArray {

	public static void main(String[] args) {
		
		int a[]= {10,20,10,30,20,10,40,30,30,30,30};
		int n=a.length;
		
		Map<Integer,Integer> mp=new LinkedHashMap<Integer,Integer>();
		
		for(int i=0;i<n;i++)//i=1,1<7
		{
			if(mp.containsKey(a[i]))///
			{
				mp.put(a[i], (mp.get((a[i])))+1);
			}
			else
			{
				mp.put(a[i],1);
			}
		}
		
		for(Map.Entry m:mp.entrySet())
		{
			System.out.print(m.getKey()+"  ");
			System.out.println(m.getValue());
		}
		
		int maxFrequency=0;//3
		int maxOccurringInteger =0;
		
		for (Map.Entry<Integer, Integer> entry : mp.entrySet()) {
	        if (entry.getValue() > maxFrequency) {//3>0//2>3
	            maxFrequency = entry.getValue();//3
	            maxOccurringInteger = entry.getKey();//10
	        }
	    }
		
		  System.out.println("Maximum occurring character: '" + maxOccurringInteger + "' with a frequency of " + maxFrequency);
		
		
		
		

	}

}
