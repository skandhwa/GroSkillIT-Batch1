package MyPractice;

public class DataTypesExample {

	public static void main(String[] args) {
		
		boolean x=true;
		boolean y=false;
		
		
		byte g=-34;
		byte h=127;//-128 to +127
		short j=4345;
		int b=321333321;
		long n=12321312321321l;
		float p=1232131232112312312321.123123123123123123f;
		double q=1231231231233333333333333333312312312312312.2343242343243243243243243243;
		char ch='A';
		
		
		
		
		
		

	}

}
