package MyPractice;

public class UsingTernaryOperator {

	public static void main(String[] args) {
		
		int a=100;
		int b=20;
		 
		int max= (a>b)? a:b;
		System.out.println(max);

	}

}
