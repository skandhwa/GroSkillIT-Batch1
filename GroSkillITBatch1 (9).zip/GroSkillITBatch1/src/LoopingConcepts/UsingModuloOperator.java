package LoopingConcepts;

public class UsingModuloOperator {

	public static void main(String[] args) {
		
		int num=1;
		int x=num%10;
		System.out.println(x);

	}

}
