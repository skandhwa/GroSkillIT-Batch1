package LoopingConcepts;

public class SumofNumbers {

	public static void main(String[] args) {
		
		int x=1,sum=0;
		
		while(x<=15)//1<=5//2<=5
		{
			sum=sum+x;///sum=0+1=1//sum=1+2=3//sum=3+3=6
			x++;
		}
		
		System.out.println("The sum is "+sum);
		

	}

}
