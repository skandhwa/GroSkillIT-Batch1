package LoopingConcepts;

public class NestedForLoopExample {

	public static void main(String[] args) {
		
		for(int i=0;i<=2;i++)///i=0,0<=3//1,1<=3
		{
			for(int j=0;j<=2;j++)/// j=0,0<=2//1, 1<=2
			{
				System.out.println(i+ " "+j );//1 0 // 1 1//
			}
		}
		

	}

}
