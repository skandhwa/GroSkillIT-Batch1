package LoopingConcepts;

public class forloopExamples {

	public static void main(String[] args) {
		
		for(int i=1;i<=5;i++)///i=1,1<=5 //2<=5 //3<=5 //4<=5 //5<=5  //6<=5
		{
			System.out.print(i+" "); //1 //2 //3 //4 //5
			//1++ //2++ //3++ //4++ //5++
		}
		

	}

}
