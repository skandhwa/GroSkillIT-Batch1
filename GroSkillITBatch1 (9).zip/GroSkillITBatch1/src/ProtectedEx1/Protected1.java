package ProtectedEx1;

public class Protected1 {
	
	protected void display()
	{
		System.out.println("hello");
	}
	

	public static void main(String[] args) {
		
		Protected1 obj=new Protected1();
		obj.display();
		
		
		

	}

}
