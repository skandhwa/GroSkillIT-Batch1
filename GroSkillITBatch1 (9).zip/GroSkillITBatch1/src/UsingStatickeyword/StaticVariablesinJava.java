package UsingStatickeyword;

class Employee
{
	int eid;
	String ename;
	static String companyname="TCS";
	Employee(int i,String n)
	{
		eid=i;
		ename=n;
	}
	
	void display()
	{
		System.out.println(eid+ " "+ename+" "+companyname);
	}
}


public class StaticVariablesinJava {

	public static void main(String[] args) {
		
		Employee obj=new Employee(1234,"Mahesh");
		Employee obj1=new Employee(6789,"Ramesh");
		obj.display();

	}

}
