package UsingStatickeyword;

public class UsingStaticBlock {
	
	
	UsingStaticBlock()
	{
		System.out.println("Hi I am default constructor");
	}
	
	static
	{
		System.out.println("Hello how are you");
	}
	
	
	void test()
	{
		System.out.println("hello");
	}

	public static void main(String[] args) {
		
		UsingStaticBlock obj=new UsingStaticBlock();
		obj.test();
		

	}

}
