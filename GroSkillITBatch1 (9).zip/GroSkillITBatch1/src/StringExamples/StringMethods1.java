package StringExamples;

public class StringMethods1 {

	public static void main(String[] args) {
		
		String str="Republic";
		///charAt
		
		char ch=str.charAt(5);
		System.out.println(ch);
		
		int x=str.length();
		System.out.println(x);
		
	String str2=	str.substring(5);
	System.out.println(str2);
	
	String str3=str.substring(-7,-2);
	System.out.println(str3);
	
	
		
		
		
		
		

	}

}
