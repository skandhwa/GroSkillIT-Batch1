package StringExamples;

public class StringMethods8 {

	public static void main(String[] args) {

      String str="India is a vast country and India is a democratic country and India is a secular country";
    int x=  str.indexOf("is",36);
    System.out.println("Index of country is "+x);
    
      
		

	}

}
