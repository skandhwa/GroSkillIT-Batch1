package InheritanceExample;

class X4 
{
	int x=30;
}

class Y1 extends X4
{
	int x=10;
	void display()
	{
		System.out.println("The self variable value is "+x);
		System.out.println("The Grand parent variable value is "+super.x);
	}
	
}

class Y2 extends Y1
{
	int x=20;
	void test()
	{
		System.out.println("The subclass variable value is "+x);
		System.out.println("The superclass variable value is "+super.x);
	}
}



public class UsingSuperKeyword {

	public static void main(String[] args) {
		
		Y2 obj=new Y2();
		obj.test();
		obj.display();
		

	}

}
