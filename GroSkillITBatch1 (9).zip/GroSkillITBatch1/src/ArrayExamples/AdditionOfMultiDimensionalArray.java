package ArrayExamples;

public class AdditionOfMultiDimensionalArray {

	public static void main(String[] args) {
		
		System.out.println("Elements of first array are");
		
		int a[][]= {{1,2,3},{4,5,6},{7,8,9}};
		for(int i=0;i<a.length;i++)///i=0,0<3//i=1,1<3
		{
			
			for(int j=0;j<a.length;j++)//j=0,0<3
			{
				System.out.print(a[i][j]+" "); //a[1]00]//a[0][1]//a[0][2]
			}
			
			System.out.println();
			
		}
		
		System.out.println();
		System.out.println();
		System.out.println("Elements of second array are");
		int b[][]= {{2,8,9},{1,4,7},{3,6,5}};
		for(int i=0;i<b.length;i++)///i=0,0<3//i=1,1<3
		{
			
			for(int j=0;j<b.length;j++)//j=0,0<3
			{
				System.out.print(b[i][j]+" "); //a[1]00]//a[0][1]//a[0][2]
			}
			
			System.out.println();
			
		}
		System.out.println();
		System.out.println("Elements of third array after addition are");
		System.out.println();
		System.out.println();
		
		int c[][]=new int [3][3];
		for(int i=0;i<c.length;i++)///i=0,0<3//i=1,1<3
		{
			
			for(int j=0;j<c.length;j++)//j=0,0<3
			{
				 c[i][j]=a[i][j]+b[i][j];
				 System.out.print(c[i][j]+" ");
			}
			
			System.out.println();
			
		}
		
		
		

		
	}

}
