package ArrayExamples;

public class PrintingArrayinReverseOrder {

	public static void main(String[] args) {
		
		int a[]= {2,3,4,5,6,7};
		
		System.out.println("Elements of Original array are");
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
		
		System.out.println();
		System.out.println("Elements of Reverse array are");
		
		for(int i=a.length-1;i>=0;i--)
		{
			System.out.print(a[i]+" ");
		}
		
		
		

	}

}
