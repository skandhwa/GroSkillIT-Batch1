package LoopingConcepts;

public class OddEvenProgramsExample {

	public static void main(String[] args) {
		
		int num=17;
		if(num%2==0)
		{
			System.out.println("Even Number");
		}
		else
		{
			System.out.println("Odd number");
		}
		

	}

}
