package MyPractice;

public class AssignmentOperatorEx {

	public static void main(String[] args) {
		
		int a=5;
		a+=20;//
		System.out.println(a);
		

	}

}
