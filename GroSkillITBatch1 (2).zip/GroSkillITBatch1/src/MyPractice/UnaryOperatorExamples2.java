package MyPractice;

public class UnaryOperatorExamples2 {

	public static void main(String[] args) {
		
		int i=5;
		
		while(i<=8)///5<=8//6<=8//7<=8//8<=8
		{
			System.out.println(i);//5//6//7//8
			i++;//5++//6++//7++//8++
		}
		
		
		
		
		
		

	}

}
