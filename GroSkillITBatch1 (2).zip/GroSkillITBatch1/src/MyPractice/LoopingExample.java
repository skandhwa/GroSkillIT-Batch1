package MyPractice;

public class LoopingExample {

	public static void main(String[] args) {
	
		int x=2;
		if(x>3)
		{
			System.out.println("True");
		}
		else
		{
			System.out.println("false");
		}

	}

}
