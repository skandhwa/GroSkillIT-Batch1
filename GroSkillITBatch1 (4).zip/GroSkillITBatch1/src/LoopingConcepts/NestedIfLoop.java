package LoopingConcepts;

public class NestedIfLoop {

	public static void main(String[] args) {
		
		int age=76;
		char status='A';
		
		if(age>18)
		{
			System.out.println("you are an adult");
			if(age<75)
			{
				System.out.println("You are not super senior citizen");
				if(status=='A')
				{
				
				System.out.println("please come to booth for polling the vote");
				}
			}
		}
		
		
		System.out.println("Voting complete with /without cast");
		

	}

}
