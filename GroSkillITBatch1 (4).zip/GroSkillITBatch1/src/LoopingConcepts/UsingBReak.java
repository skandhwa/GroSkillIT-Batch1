package LoopingConcepts;

public class UsingBReak {

	public static void main(String[] args) {
		
          for(int i=0;i<=4;i++)//i=0,0<=4, 1<=4,, 2<=4 ,,i=3,3<=4
          {
        	  if(i==2)
        	  {
        		  break;
        	  }
        	  System.out.println(i);//0//1//3
          }
          
          
		
	}

}
