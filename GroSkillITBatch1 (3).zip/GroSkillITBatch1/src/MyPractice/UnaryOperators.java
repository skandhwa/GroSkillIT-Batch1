package MyPractice;

public class UnaryOperators {

	public static void main(String[] args) {
		
		int a=10;
		
		int b=20;
		
		int d=30;
		
		
	/*	int b= ++a; ///prefix increment
		
		int c= a++;// postfix increment
		
		int d= --a; //prefix decrement
		
		*/
		
		int b= a++;
		System.out.println(b);
		
		
		int c= ++a + ++b + a++;
		
		/// 11 + 21 + 11
		
		
		
		
		
		
		
		

	}

}
