package LoopingConcepts;

public class ifloopExample {

	public static void main(String[] args) {
		
		int x=5;
		if(x>7)
		{
			System.out.println("hello");
		}
		
		System.out.println("Execution done");
		

	}

}
