package LoopingConcepts;

public class CatSelectionIfElse {

	public static void main(String[] args) {
		
		int marks=90;
		int percentile=99;
		char behaviour='B';
		
		if(marks>65)
		{
			if(percentile>95)
			{
				if(behaviour=='G')
				{
					System.out.println("You are elligible");
				}
			}
		}
		
		
		
		
		
		//System.out.println("Your selection may or may not be confirmed");
		
		

	}

}
