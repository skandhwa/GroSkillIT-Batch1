package MyBasics;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands5 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		WebElement ele=	driver.findElement(By.xpath("//input[@placeholder='First Name']"));
		Dimension d=ele.getSize();
		System.out.println("Height of web element is "+d.getHeight());
		System.out.println("Width of web element is "+d.getWidth());
		
		/////isSelectedExample
		
	WebElement ele2=	driver.findElement(By.xpath("//input[@id='checkbox1']"));
	ele2.click();
	
	Thread.sleep(5000);
	
boolean flag=	ele2.isSelected();
System.out.println("Is the element selected "+flag);

 WebElement ele3=  driver.findElement(By.xpath("//button[@id='submitbtn']"));
String TagName=	ele3.getTagName();
System.out.println(TagName);
	

	}

}
