package MyBasics;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWindowsDifferentTab {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
	String WindowID=	driver.getWindowHandle();
	
	System.out.println(WindowID);
	
	driver.findElement(By.xpath("//a[@href='#Multiple']")).click();
	driver.findElement(By.xpath("(//button[@class='btn btn-info'])[2]")).click();
	
	Set<String> WindowIDS=driver.getWindowHandles();
	System.out.println(WindowIDS);
	Iterator<String> itr=WindowIDS.iterator();
	while(itr.hasNext())
	{
		String childwindow=itr.next();
		if(!WindowID.equals(childwindow))
		{
			driver.switchTo().window(childwindow);
			String Title=driver.getTitle();
			System.out.println(Title);
		}
	
	
	
	

	}

}
}
