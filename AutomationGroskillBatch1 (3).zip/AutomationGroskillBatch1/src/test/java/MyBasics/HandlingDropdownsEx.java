package MyBasics;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingDropdownsEx {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//select[@id='Skills']"));
	Select oselect =new Select(ele);
	Thread.sleep(3000);
	//oselect.selectByIndex(2);
	//oselect.selectByVisibleText("Android");
	
	//oselect.selectByValue("Analytics");
	
	
	
  List<WebElement> li=	oselect.getOptions();

  int x=li.size();
  System.out.println("size is "+x);
  
  for(int j=0;j<x;j++)//j=0,0<78
  {
	  System.out.println(li.get(j).getText());///li.get(0).getText
  }

	
	
	
		
		

	}

}
