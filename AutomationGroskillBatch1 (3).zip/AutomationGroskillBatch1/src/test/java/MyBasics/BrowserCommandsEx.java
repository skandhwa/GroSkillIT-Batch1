package MyBasics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BrowserCommandsEx {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		driver.manage().window().maximize();
//	String Title=	driver.getTitle();
//	System.out.println(Title);
//	
//String CurrentURL=	driver.getCurrentUrl();
//System.out.println(CurrentURL);
		
	String PageSource=	driver.getPageSource();
	System.out.println(PageSource);
	
	
	
	

	}

}
