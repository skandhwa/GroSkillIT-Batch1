package MyBasics;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingDynamicWebTable {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("file:///C://Users//saura//Downloads//WebTable.html");
		driver.manage().window().maximize();
		String before_xpath="//table/tbody/tr[";
		String after_xpath="]/td[2]";
		
	List<WebElement> li=	driver.findElements(By.xpath("//table/tbody/tr"));
	int x=li.size();
	System.out.println("The total size of list is "+x);
	
	for(int i=2;i<=x;i++)
	{
	String names=	driver.findElement(By.xpath(before_xpath+i+after_xpath)).getText();
	System.out.println(names);
	if(names.contains("Will"))
	{
		String  before_xpath_cbox="//table/tbody/tr[";
		String after_xpath_cbox="]/td[1]/input";
		
	WebElement ele=	driver.findElement(By.xpath(before_xpath_cbox+i+after_xpath_cbox));
	ele.click();
		
	System.out.println("candidtae selected");
	
	}
	
	
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
		
		
		
	}

}
