package MyBasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingDynamicWebTableUsingXpathAxes {

	public static void main(String[] args) {
		
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("file:///C://Users//saura//Downloads//WebTable.html");
		driver.manage().window().maximize();
		
WebElement ele=		driver.findElement(By.xpath("//td[contains(text(),'Tom')]//preceding-sibling::td//input[@type='checkbox']"));
WebElement ele2=		driver.findElement(By.xpath("//td[contains(text(),'Jessica')]//preceding-sibling::td//input[@type='checkbox']"));
		
		ele.click();
		ele2.click();

	}

}
