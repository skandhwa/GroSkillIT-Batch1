package ReUsableMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MethodDefinition {
	
	
	
	public static void openBrowser()
	{
	  WebDriver driver;
	driver=new ChromeDriver();
	driver.get("https://www.google.com/");
	driver.manage().window().maximize();
	}
	
	public static void entervalue(String text)
	{
		
		
		
		driver.get("https://www.google.com/");
WebElement ele=		driver.findElement(By.xpath("//textarea[@class='gLFyf']"));
		ele.sendKeys(text);
	}
	
	public static void clickOnLink()
	{
		
		
		driver.findElement(By.xpath("//a[text()='Gmail']")).click();
	}
	
	
	
	
	
	

}
