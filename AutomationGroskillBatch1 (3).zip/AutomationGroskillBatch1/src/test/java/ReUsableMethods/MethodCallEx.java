package ReUsableMethods;

import java.time.Duration;

public class MethodCallEx {

	public static void main(String[] args) throws InterruptedException {
		
		MethodDefinition.entervalue("Java Selenium");
		Thread.sleep(3000);
		MethodDefinition.clickOnLink();
		

	}

}
