package TestNgCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNgTimeOut {
	
	@Test(timeOut=15000)
	public void test() throws InterruptedException
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		Thread.sleep(6000);
	String title=	driver.getTitle();
	System.out.println("The title of webpage is "+title);
		
		
		
	}
	

}
