package TestNgCases;

import org.testng.annotations.Test;

public class TestNgGroupEx {
	
	@Test(groups= {"sanity"})
	public void display()
	{
		System.out.println("Hello");
	}
	

	@Test(groups= {"sanity"})
	public void show()
	{
		System.out.println("Hi");
	}
	
	
	@Test(groups= {"smoke"})
	public void test()
	{
		System.out.println("Java");
	}
	
	@Test(groups= {"smoke"})
	public void message()
	{
		System.out.println("Selenium");
	}
	

}
