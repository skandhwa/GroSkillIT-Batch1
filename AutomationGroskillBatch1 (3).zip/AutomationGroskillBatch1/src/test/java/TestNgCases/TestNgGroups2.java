package TestNgCases;

import org.testng.annotations.Test;

public class TestNgGroups2 {
	
	@Test(groups= {"sanity_1"})
	public void test1()
	{
		System.out.println("hello");
	}
	
	@Test(groups= {"sanity_2"})
	public void test2()
	{
		System.out.println("hello");
	}
	
	@Test(groups= {"sanity_3"})
	public void test3()
	{
		System.out.println("hello3");
	}
	
	
	

}
