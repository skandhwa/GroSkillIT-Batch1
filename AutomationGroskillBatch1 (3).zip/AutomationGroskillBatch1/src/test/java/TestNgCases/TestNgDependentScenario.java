package TestNgCases;

import org.testng.annotations.Test;

public class TestNgDependentScenario {
	
	@Test
	public void SearchProduct()
	{
		int x=9/0;
		System.out.println("I am SearchProduct method ");
	}
	
	@Test(dependsOnMethods={"SearchProduct"})
	public void AddtoCart()
	{
		
		//System.out.println(x);
		System.out.println("I am Add to cart method ");
	}
	
	@Test(dependsOnMethods={"SearchProduct","AddtoCart"})
	public void PaymentGateway()
	{
		System.out.println("I am payment gateway method ");
	}
	

}
