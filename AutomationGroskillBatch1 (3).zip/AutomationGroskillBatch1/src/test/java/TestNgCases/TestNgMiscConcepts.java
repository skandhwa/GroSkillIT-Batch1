package TestNgCases;

import org.testng.annotations.Test;

public class TestNgMiscConcepts {
	
	@Test
	public void sum()
	{
		System.out.println("Hello");
	}
	
	
	@Test(enabled=false)
	public void display()
	{
		System.out.println("Hi");
	}
	
	
	@Test
	public void test()
	{
		System.out.println("Java");
	}

}
