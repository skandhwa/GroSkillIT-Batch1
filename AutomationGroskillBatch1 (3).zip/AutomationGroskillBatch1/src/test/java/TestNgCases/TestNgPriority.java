package TestNgCases;

import org.testng.annotations.Test;

public class TestNgPriority {
	
	@Test(priority=4)
	public void test()
	{
		System.out.println("I am priority 4");//6
	}
	
	
	@Test(priority=0)
	public void test2()
	{
		System.out.println("I am priority 0");//3
	}
	
	@Test(priority=2)
	public void D()
	{
		System.out.println("I am priority 2 method D");//5
	}
	
	@Test(priority=-3)
	public void test3()
	{
		System.out.println("I am priority -3");//1
	}
	
	@Test(priority=2)
	public void A()
	{
		System.out.println("I am priority 2 Method A");//4
	}
	
	
	@Test
	public void test1()
	{
		System.out.println("I am default priority ");//2
	}
	
	
	@Test(priority='C')
	public void B()
	{
		System.out.println("I am priority C");//7
	}





	

}
