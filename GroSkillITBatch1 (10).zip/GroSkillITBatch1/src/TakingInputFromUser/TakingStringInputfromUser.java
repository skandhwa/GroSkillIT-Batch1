package TakingInputFromUser;

import java.util.Scanner;

public class TakingStringInputfromUser {

	public static void main(String[] args) {
		
		System.out.println("Enter the String");
		Scanner sc=new Scanner(System.in);
		
		String str=sc.nextLine();
		int x=str.length();
		System.out.println("Length of String is "+x);
		
		System.out.println("Enter any character");
		char ch=sc.next().charAt(0);
		System.out.println("The character you entered is "+ch);
		
		
		

	}

}
