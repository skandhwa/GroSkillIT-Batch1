package ConstructorinJava;

class Test2
{
	Test2()
	{
		System.out.println("Hello I am constructor");
	}
	
	void display()
	{
		System.out.println("Test");
	}
}

public class UsingDefaultConstructor {

	public static void main(String[] args) {
		
		Test2 obj=new Test2();
		obj.display();
		

	}

}
