package ArrayExamples;

class ArraySearch
{
	public static int search(int[]a,int k)
	{
		for(int i=0;i<a.length;i++)//i=0,0<5//i=1,1<5//i=2,2<5
		{
			if(a[i]==k)///
			{
				return i;
			}
		}
		
		return -1;
		
		
		
	}
}

public class SearchAnElementinArray {

	public static void main(String[] args) {
		
		int a1[]= {12,45,78,96,44,88,54,90};
		int k=44;
		System.out.println(k+" is found at the index of  "+ArraySearch.search(a1,k));
		
		
		

	}

}
