package UsingThisKeyword;

class Student3
{
	int roll;
	String name;
	String college;
	float fee;
	
	Student3(int roll,String name,String college)
	{
		this.roll=roll;
		this.name=name;
		this.college=college;
		
	}
	Student3(int roll,String name,String college,float fee)
	{
		this(roll,name,college);
		this.fee=fee;
	}
	
	void display()
	{
		System.out.println(roll+" "+name+" "+college+" "+fee);
	}
	
}


public class UsingThisinConstructor {

	public static void main(String[] args) {
		
		Student3 obj=new Student3(1234,"Harry","ITER");
		obj.display();
		
		Student3 obj1=new Student3(4567,"Tom","KIIT",560000f);
		obj1.display();
		
		

	}

}
