package DefaultEx1;

public class Default2 {

	public static void main(String[] args) {
		
		
		C14 obj=new C14();
		obj.display();
		

	}

}
