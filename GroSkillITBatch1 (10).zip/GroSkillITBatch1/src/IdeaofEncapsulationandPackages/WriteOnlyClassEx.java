package IdeaofEncapsulationandPackages;

class Bank14
{
	private String email;
	private String name;
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
}


public class WriteOnlyClassEx {

	public static void main(String[] args) {
		
		Bank14 obj=new Bank14();
		obj.setEmail("abcd@gmail.com");
		obj.setName("Monty");

	}

}
