package SetExamples;

import java.util.HashSet;
import java.util.Set;

public class HashSetExample {

	public static void main(String[] args) {
		
		Set<String> s1=new HashSet<String>();
		s1.add("kiwi");
		s1.add("Orange");
		s1.add("apple");
		s1.add("grapes");
		s1.add("apple");
		
		
		Set<String> s2=new HashSet<String>();
		s2.add("pines");
		s2.add("mango");
		s2.add("apple");
		s2.add("grapes");
		
		
		for(String x:s1)
		{
			System.out.println(x);
		}
	   //s1.remove("apple");
	   System.out.println("After removing elements are");
	   s1.removeAll(s2);
	   for(String y:s1)
		{
			System.out.println(y);
		}
		
		s1.addAll(s2);
		
		System.out.println("after adding elements are");
		 for(String z:s1)
			{
				System.out.println(z);
			}
		 
		 
		 s1.clear();
		 System.out.println("after clearing elements are");
		 for(String p:s1)
			{
				System.out.println(p);
			}
		 
	boolean flag=	 s1.isEmpty();
	System.out.println("Is the Set empty "+flag);
			

	}

}
