package SetExamples;

import java.util.TreeSet;

public class TreeSetEx2 {

	public static void main(String[] args) {
		
		TreeSet<Integer> t1=new TreeSet<Integer>();
		t1.add(134);
		t1.add(14);
		t1.add(194);
		t1.add(64);
		t1.add(104);
		
		System.out.println("Lowest value is "+t1.pollFirst());
		System.out.println("Highest value is "+t1.pollLast());

	}

}
