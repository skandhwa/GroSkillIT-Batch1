package SetExamples;

import java.util.HashSet;
import java.util.Set;

public class HashSetMethods1 {

	public static void main(String[] args) {
		
		Set<String> s1=new HashSet<String>();
		s1.add("kiwi");
		s1.add("Orange");
		s1.add("apple");
		s1.add("grapes");
		s1.add("apple");
		
	boolean flag=	s1.contains("kiwi");
	System.out.println(flag);
		
		

	}

}
