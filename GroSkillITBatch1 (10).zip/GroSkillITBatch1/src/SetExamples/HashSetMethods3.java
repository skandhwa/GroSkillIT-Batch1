package SetExamples;

import java.util.HashSet;
import java.util.Set;

public class HashSetMethods3 {

	public static void main(String[] args) {
		
		Set<String> s1=new HashSet<String>();
		s1.add("kiwi");
		s1.add("Orange");
		s1.add("apple");
		s1.add("grapes");
	
		Set<String> s2=new HashSet<String>();
		s2.add("banana");
		s2.add("melon");
		s2.add("apple");
		s2.add("grapes");
		
//		s1.retainAll(s2);
//		
//		for(String x:s1)
//		{
//			System.out.println(x);
//		}
		
		
		s1.removeAll(s2);
		System.out.println();
		System.out.println("Difference between s1 and s2 is ");
		for(String x:s1)
		{
			System.out.println(x);
		}
		

	}

}
