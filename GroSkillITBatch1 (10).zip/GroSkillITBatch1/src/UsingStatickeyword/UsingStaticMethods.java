package UsingStatickeyword;

public class UsingStaticMethods {
	
	static void display()
	{
		System.out.println("Hello");
	}
	
	

	public static void main(String[] args) {
		
		UsingStaticMethods.display();
		
		

	}

}
