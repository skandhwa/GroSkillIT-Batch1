package MapExamples;

import java.util.TreeMap;

public class TreeMapEx1 {

	public static void main(String[] args) {
		
		TreeMap<Integer,String> mp=new TreeMap<Integer,String>();
		
		mp.put(2,"Saurabh");
		mp.put(22,"Gaurabh");
		mp.put(5,"Mohan");
		mp.put(12,"Sohan");
		mp.put(9,"Prakash");
		mp.put(4,"Harish");
		
		System.out.println(mp);
		
		
		System.out.println("HeadMap values are "+mp.headMap(10));
		
		System.out.println("tailMap values are "+mp.tailMap(13));
		
		System.out.println("SubMap values are "+mp.subMap(12,false,20,false));
		
		
		
		
		
		
		

	}

}
