package MapExamples;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfCharacter {

	public static void main(String[] args) {
		
		
		String str="Mahesh";
		Map<Character,Integer> mp=new LinkedHashMap<Character,Integer>();
		char []strArray=str.toCharArray();
		for(char c:strArray)
		{
			if(mp.containsKey(c))
			{
				mp.put(c, (mp.get(c)+1));
			}
			else
			{
				mp.put(c,1);
			}
		}
		
		
		for(Map.Entry m:mp.entrySet())
		{
			System.out.print(m.getKey()+"  ");
			System.out.println(m.getValue());
		}
		
		int maxFrequency=0;
		char maxOccurringChar = ' ';
		
		for (Map.Entry<Character, Integer> entry : mp.entrySet()) {
	        if (entry.getValue() > maxFrequency) {
	            maxFrequency = entry.getValue();
	            maxOccurringChar = entry.getKey();
	        }
	    }
		
		  System.out.println("Maximum occurring character: '" + maxOccurringChar + "' with a frequency of " + maxFrequency);
		
		
		
		
		
		
		

	}

}
