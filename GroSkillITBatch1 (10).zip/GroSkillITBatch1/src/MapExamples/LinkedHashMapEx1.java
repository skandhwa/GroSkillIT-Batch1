package MapExamples;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapEx1 {

	public static void main(String[] args) {
		
		
		Map<Integer,String> mp=new LinkedHashMap<Integer,String>();
		mp.put(2,"Saurabh");
		mp.put(12,"Gaurabh");
		mp.put(22,"Mohan");
		
		System.out.println(mp);
		

	}

}
