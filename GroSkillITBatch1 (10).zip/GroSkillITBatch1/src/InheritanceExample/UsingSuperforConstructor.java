package InheritanceExample;

class Student
{
	int id;
	String name;
	Student(int i,String n)
	{
		id=i;
		name=n;
	}
}

class Person extends Student
{
	float salary;
	Person(int id,String name,float s)
	{
		super(id,name);
		salary=s;
	}


void display()
{
	System.out.println(id+" "+name+" "+salary);
}
}


public class UsingSuperforConstructor {

	public static void main(String[] args) {
		
		Person obj=new Person(23,"tom",5600f);
		obj.display();
		
	}
		

	}


