package Protected2;

import ProtectedEx1.Protected1;

public class ProtectedEx3 extends Protected1 {

	public static void main(String[] args) {
		
		ProtectedEx3 obj=new ProtectedEx3();
		obj.display();
		

	}

}
