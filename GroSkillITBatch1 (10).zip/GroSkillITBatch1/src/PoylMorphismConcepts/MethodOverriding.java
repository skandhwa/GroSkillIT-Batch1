package PoylMorphismConcepts;

class Bank
{
	 static int getROI(int x,int y)
	{
		return x+y;
	}
}

class SBI extends Bank
{
	static  int getROI(int x,int y)
	{
		return x+y;
	}
}

public class MethodOverriding {

	public static void main(String[] args) {
		
		SBI obj=new SBI();
		obj.getROI(3, 4);
		
		Bank obj1=new Bank();
		obj1.getROI(4, 4);
		
		

	}

}
