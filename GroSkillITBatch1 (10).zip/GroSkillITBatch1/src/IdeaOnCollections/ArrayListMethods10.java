package IdeaOnCollections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayListMethods10 {

	public static void main(String[] args) {
	
		String []fruits= {"melon","kiwi","apple"};
		
		List <String> a=new ArrayList<String>();
		a=Arrays.asList(fruits);
		
		System.out.println(a);
		
		
		
		
		
		
		
		

	}

}
