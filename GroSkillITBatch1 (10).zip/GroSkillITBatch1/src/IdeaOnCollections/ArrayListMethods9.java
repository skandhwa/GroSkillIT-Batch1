package IdeaOnCollections;

import java.util.ArrayList;
import java.util.List;

public class ArrayListMethods9 {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(56);
		li.add(98);
		li.add(77);
		li.add(98);
		System.out.println(li);
		
		
		
		li.removeIf(e -> (e%2)==0);
		System.out.println("After removing even numbers elements are");
		System.out.println(li);
		

	}

}
