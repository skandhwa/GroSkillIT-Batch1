package IdeaOnCollections;

import java.util.Stack;

public class StackExamples {

	public static void main(String[] args) {
		
		Stack<Integer> s1=new Stack<Integer>();
		s1.push(34);
		s1.push(56);
		s1.push(87);
		s1.push(99);
		
		s1.pop();
		s1.pop();
		
		
		System.out.println(s1);
		

	}

}
