package IdeaOnCollections;

import java.util.ArrayList;
import java.util.List;

public class ArrayListethods3 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("melon");
		li.add("guava");
		li.add("banana");
		li.add("apple");
		li.add("papaya");
		
		
		List<String> li2=new ArrayList<String>();
		li2.add("kiwi");
		li2.add("mango");
		li2.add("grapes");
		li2.add("orange");
		li2.add("apple");
		
		li.addAll(li2);
		
		System.out.println();
		System.out.println();
		System.out.println("After merging elements are ");
		for(String x:li)
		{
			System.out.println(x);
		}
		
		

	}

}
