package PublicExample1;

public class Public1 {
	
	public void display()
	{
		System.out.println("hello");
	}

	public static void main(String[] args) {
		
		Public1 obj=new Public1();
		obj.display();
		

	}

}
