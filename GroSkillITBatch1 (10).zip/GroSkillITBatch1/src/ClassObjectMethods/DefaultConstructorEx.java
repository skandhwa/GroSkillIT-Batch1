package ClassObjectMethods;

class Test3
{
	Test3()
	{
		System.out.println("Hi");
	}
	
	void display()
	{
		System.out.println("hello");
	}
}

public class DefaultConstructorEx {

	public static void main(String[] args) {
		Test3 obj=new Test3();
		obj.display();
		

	}

}
