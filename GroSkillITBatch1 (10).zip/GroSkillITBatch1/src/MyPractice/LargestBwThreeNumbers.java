package MyPractice;

public class LargestBwThreeNumbers {

	public static void main(String[] args) {
		
		int a=100,b=15,c=12;
		
		int max= (a>b)? (a>c?a:c) :(b>c?b:c);
		
		System.out.println(max);
		
		
	}

}
