package MyPractice;

public class ArithmeticOperatorEx {

	public static void main(String[] args) {
		
		int a=38;
		int b=3;
		int c=a/b;
		System.out.println(c);
		
	///	+,- ,*,/,%
		

	}

}
