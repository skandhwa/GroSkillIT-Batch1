package LoopingConcepts;

public class NeverEndingLoop {

	public static void main(String[] args) {
		
		while(true)
		{
			System.out.println("Infinite times");
		}
		

	}

}
