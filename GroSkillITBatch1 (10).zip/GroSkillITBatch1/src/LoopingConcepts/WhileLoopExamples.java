package LoopingConcepts;

public class WhileLoopExamples {

	public static void main(String[] args) {
		
		int i=5;   ///initialization
		
		while(i<=2)//5<=8//6<=8//7<=8//8<=8//9<=8  ///condition checking
		{
			System.out.println(i);//5//6//7//8
			i++;//5++//6++//7++//8++ ///increment/decrement operation
		}
		

	}

}
