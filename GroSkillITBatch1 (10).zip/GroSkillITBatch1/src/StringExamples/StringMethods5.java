package StringExamples;

public class StringMethods5 {

	public static void main(String[] args) {
		
		String str="Json Jackson";
	String str1=	str.replace('J','s');
		System.out.println(str1);
		

	}

}
