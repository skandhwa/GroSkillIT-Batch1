package StringExamples;

public class StringMethods7 {

	public static void main(String[] args) {
		
		String str="abcd @hjyt test";
		String []arr=str.split("@");
		
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		
		
		
		

	}

}
