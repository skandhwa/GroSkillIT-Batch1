package StringExamples;

public class CountVowelsandConsonants {

	public static void main(String[] args) {
		
		int vcount=0;
		int cCount=0;
		
		String str="India is a vast country";
		str=str.toLowerCase();
		
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)=='a' || str.charAt(i)=='e' ||str.charAt(i)=='i'
					|| str.charAt(i)=='o' ||str.charAt(i)=='u')
			{
				vcount++;
			}
			else
			{
				if(str.charAt(i)>='a' && str.charAt(i)<='z')
				{
					cCount++;
				}
			}
			
		}
		
		System.out.println("Total vowel count is  "+vcount);
		System.out.println("Total consonant count is  "+cCount);
		
		

	}

}
