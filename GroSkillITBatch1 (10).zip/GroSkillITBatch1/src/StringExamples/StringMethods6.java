package StringExamples;

public class StringMethods6 {

	public static void main(String[] args) {
		
		String str="India is a vast country and democratic country , country with huge taxes";
		
	String str1=	str.replaceFirst("country", "nation");
	
	String str2=str.replaceAll("country","nation");
	
	System.out.println(str1);
		
		
		

	}

}
