package StringExamples;

public class StringMethods9 {

	public static void main(String[] args) {
		
		String str="         IND    IA           ";
		String str1=str.toLowerCase();
		System.out.println(str1);
		
		
//	String str2=	str.trim();
//	System.out.println(str2);
	
	String str3=str.replace(" ","");
	System.out.println(str3);
	
	
	
	int val=20;
	System.out.println(val+30);
	
	
	
	String str4=String.valueOf(val);
	System.out.println(str4+20);
	
	
	
	
		
		
		

	}

}
