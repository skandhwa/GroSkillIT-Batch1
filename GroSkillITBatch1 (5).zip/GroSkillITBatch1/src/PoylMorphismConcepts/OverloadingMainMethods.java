package PoylMorphismConcepts;

public class OverloadingMainMethods {
	
	public static void main()
	{
		System.out.println("hello");
	}

	public static void main(String[] args) 
	{
		OverloadingMainMethods.main();
		
		

	}

}
