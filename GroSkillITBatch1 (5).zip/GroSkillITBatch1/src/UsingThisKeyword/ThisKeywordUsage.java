package UsingThisKeyword;

class Employee2
{
	int id;
	String name;
	String address;
	Employee2(int id,String name,String address)
	{
		this.id=id;
		this.name=name;
		this.address=address;
	}
	void display()
	{
		System.out.println(id+" "+name+" "+address);
	}
	
	
}
public class ThisKeywordUsage {

	public static void main(String[] args) {
		
		Employee2 obj=new Employee2(1234,"Harry","Kolkata");
		obj.display();
		
		
		
		

	}

}
