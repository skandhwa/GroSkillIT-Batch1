package UsingThisKeyword;

class B1
{
	void m()
	{
		System.out.println("Hello");
	}
	
	void n()
	{
		System.out.println("Hi");
		this.m();
	}
}


public class InvokingCurrentClassMethod {

	public static void main(String[] args) {
		
		
		B1 obj=new B1();
		obj.n();
		
		
		
		
	}

}
