package UsingStatickeyword;

class Test4
{
	static int gr=10;
	int id;
	int num;
	Test4(int i,int n)
	{
		id=i;
		num=n;
	}
	
	void calculation()
	{
		double r=0.2*gr*id*0.8*num;
		System.out.println(r);
	}
	
	}


public class UsingStaticvariableEx {

	public static void main(String[] args) {
		
		Test4 obj=new Test4(43,4);
		obj.calculation();
		
		Test4 obj1=new Test4(13,2);
		obj1.calculation();
		
		

	}

}
