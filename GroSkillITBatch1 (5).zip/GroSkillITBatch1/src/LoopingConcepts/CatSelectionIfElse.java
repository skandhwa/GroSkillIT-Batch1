package LoopingConcepts;

public class CatSelectionIfElse {

	public static void main(String[] args) {
		
		int m=90;
		int per=99;
		char beh='B';
		
		if(m>65)
		{
			if(per>95)
			{
				if(beh=='G')
				{
					System.out.println("You are elligible");
				}
			}
		}
		
		
		
		
		
		//System.out.println("Your selection may or may not be confirmed");
		
		

	}

}
