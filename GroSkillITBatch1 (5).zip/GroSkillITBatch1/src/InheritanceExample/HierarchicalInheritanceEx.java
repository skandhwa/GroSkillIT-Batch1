package InheritanceExample;
class D1
{
	void display()
	{
		System.out.println("Hi");
	}
}

class D2 extends D1
{
	void test()
	{
		System.out.println("Hello");
	}
}

class D3 extends D1
{
	void message()
	{
		System.out.println("How r u");
	}
}

class D4 extends D1
{
	void run()
	{
		System.out.println("Hi Are u fine");
	}
}


public class HierarchicalInheritanceEx {

	public static void main(String[] args) {
		
		D4 obj=new D4();
		obj.display();
		obj.run();
		
		D3 obj1=new D3();
		obj1.display();
		obj1.message();
		
		
		
		
		
		

	}

}
