package PrivateModifier;

class C12
{
	private int x=20;
	private void display()
	{
		int y=x+40;
		System.out.println(y);
	}
}


public class UsingPrivate2 {

	public static void main(String[] args) {
		
		
		C12 obj=new C12();
		//obj.display();
		

	}

}
