package PrivateModifier;

public class UsingPrivate {
	
	private int x=20;
	private void display()
	{
		int y=x+50;
		System.out.println(y);
	}
	

	public static void main(String[] args) {
		
		UsingPrivate obj=new UsingPrivate();
		obj.display();

	}

}
