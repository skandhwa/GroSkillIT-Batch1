package MyPractice;

public class UnaryOperators2 {

	public static void main(String[] args) {
		
		int a=7,b=8,c=9;
		
		int r= b++ + c-- + a++ + --c - --a + ++b;
		
		  //r=  8 + 9  + 7  + 7- 7 + 10                           //b=9,c=8,a=8
		System.out.println(r);
		

	}

}
