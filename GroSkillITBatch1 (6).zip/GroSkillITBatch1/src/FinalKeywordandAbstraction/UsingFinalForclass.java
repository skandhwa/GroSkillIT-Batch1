package FinalKeywordandAbstraction;

//final class Test3B
//{
//	void display()
//	{
//		System.out.println("hello");
//	}
//}
//
//
//final class Test3C extends Test3B
//{
//	void message()
//	{
//		System.out.println("Hi");
//	}
//	
//}
//public class UsingFinalForclass {
//
//	public static void main(String[] args) {
//		
//		Test3C obj=new Test3C();
//		obj.message();
//		obj.display();
//		
//
//	}
//
//}
