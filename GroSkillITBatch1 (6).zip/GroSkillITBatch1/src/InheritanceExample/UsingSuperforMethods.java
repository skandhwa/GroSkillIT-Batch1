package InheritanceExample;


class Mammals extends Animal
{
	void run()
	{
		System.out.println("Mammals run");
	}
}


class Animal
{
	void run()
	{
		System.out.println("Animal runs");
	}
}
class Dog extends Animal
{
	void run()
	{
		System.out.println("Dog runs");
	}
	void bark()
	{
		System.out.println("Dog barks");
	}
	void eat()
	{
		System.out.println("Dog eats");
	}
	
	void features()
	{ 
		run();
		bark();
		eat();
		super.run();
		 
	}
}



public class UsingSuperforMethods {

	public static void main(String[] args) {
		Dog obj=new Dog();
		obj.features();
		
		
		

	}

}
