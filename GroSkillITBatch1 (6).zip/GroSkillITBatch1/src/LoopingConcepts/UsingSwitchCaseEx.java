package LoopingConcepts;

public class UsingSwitchCaseEx {

	public static void main(String[] args) {
		
		int n=80;
		switch(n)
		{
		case 10:
			System.out.println("I am 10");
			break;
		case 20:
			System.out.println("I am 20");
			break;
		case 30:
			System.out.println("I am 30");
			break;
		case 40:
			System.out.println("I am 40");
			break;
		default:
				System.out.println("Invalid input");
			
			
		}
		
		

	}

}
