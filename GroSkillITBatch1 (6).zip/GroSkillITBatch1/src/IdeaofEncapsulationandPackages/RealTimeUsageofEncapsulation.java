package IdeaofEncapsulationandPackages;


class Bank12 {
	
	private long accno;
	private String name,email;
	private float amount;
	
	
	public long getAccno() {
		return accno;
	}
	public void setAccno(long accno) {
		this.accno = accno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
}
	


public class RealTimeUsageofEncapsulation {

	public static void main(String[] args) {
		
		Bank12 obj=new Bank12();
		
		obj.setAccno(13123218736218736L);
		obj.setAmount(12000);
		obj.setEmail("sk1234@gmail.com");
		obj.setName("Mohan");
		
	System.out.println(obj.getAccno());	
	System.out.println	(obj.getAmount());
		
		
		
		

	}

}
