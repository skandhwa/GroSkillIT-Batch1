package DefaultEx1;


class C14
{
	void display()
	{
		System.out.println("Hello");
	}
}


public class Default1Ex {

	public static void main(String[] args) {
		
		C14 obj=new C14();
		obj.display();
		
		
		

	}

}
