package InterfaceExamples;

interface Test2
{
	void draw();
	static int cube(int x)
	{
		return x*x*x;
	}
	
	static void test2()
	{
		System.out.println("hello");
	}
}

class C11 implements Test2
{
	public void draw()
	{
		System.out.println("Hello");
	}
}

public class MethodsInInterface {

	public static void main(String[] args) {
		
		Test2 ref=new C11();
		ref.draw();
	System.out.println(Test2.cube(5));	
		Test2.test2();

	}

}
