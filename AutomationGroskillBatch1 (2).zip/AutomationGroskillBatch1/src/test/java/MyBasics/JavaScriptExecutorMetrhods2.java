package MyBasics;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaScriptExecutorMetrhods2 {

	public static void main(String[] args) throws InterruptedException, IOException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		driver.manage().window().maximize();
		JavascriptExecutor js=(JavascriptExecutor)driver;
		Thread.sleep(3000);
		js.executeScript("document.getElementById('name').value='Saurabh';");
		js.executeScript("document.getElementById('hobbies').click();");
		
		js.executeScript("location.reload()");
		
		js.executeScript("document.body.style.zoom='0.3'");
		
		

TakesScreenshot scrshot=((TakesScreenshot)driver);

File SrcFile=scrshot.getScreenshotAs(OutputType.FILE);

File DestFile=new File("C:\\Users\\saura\\OneDrive\\Pictures\\ScreenShotNew\\"+Math.random()+"Scenario1"+"Test1.jpeg");

FileUtils.copyFile(SrcFile, DestFile);

   		
		
		

	}

}
