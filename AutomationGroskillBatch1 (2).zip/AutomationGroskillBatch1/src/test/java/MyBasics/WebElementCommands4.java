package MyBasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands4 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
	WebElement ele=	driver.findElement(By.xpath("(//label[@class='col-md-3 col-xs-3 col-sm-3 control-label'])[1]"));
	String TextVal=ele.getText();	
	System.out.println(TextVal);
	
WebElement ele2=	driver.findElement(By.xpath("//input[@placeholder='First Name']"));
String attributeval=	ele2.getAttribute("class");
System.out.println(attributeval);
	
		

	}

}
