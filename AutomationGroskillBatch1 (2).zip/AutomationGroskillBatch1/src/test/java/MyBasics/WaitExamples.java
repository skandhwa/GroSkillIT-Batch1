package MyBasics;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitExamples {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		//WebElement ele=	driver.findElement(By.xpath("//textarea[@class='gLFyf']"));
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		
	WebElement fname=new WebDriverWait(driver,Duration.ofSeconds(10))
			.until(ExpectedConditions.
	elementToBeClickable(By.xpath(""))));
		
		
		

	}

}
