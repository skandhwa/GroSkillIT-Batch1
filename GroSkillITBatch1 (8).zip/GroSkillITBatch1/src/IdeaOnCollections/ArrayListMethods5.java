package IdeaOnCollections;

import java.util.ArrayList;
import java.util.List;

public class ArrayListMethods5 {

	public static void main(String[] args) {
		
		
		List<String> li=new ArrayList<String>();
		li.add("melon");
		li.add("guava");
		li.add("banana");
		li.add("apple");
		li.add("papaya");
		boolean flag=li.isEmpty();
		System.out.println("Is the array list empty "+flag);
		
		
		for(String x:li)
		{
			System.out.println(x);
		}
		System.out.println("After deleting all the elements");
		
		li.clear();
		
		for(String y:li)
		{
			System.out.println(y);
		}
		
		boolean flag2=li.isEmpty();
		System.out.println("Is the array list empty "+flag2);

	}

}
