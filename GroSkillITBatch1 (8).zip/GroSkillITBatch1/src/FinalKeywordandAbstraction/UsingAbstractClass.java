package FinalKeywordandAbstraction;

abstract class Demo
{
	abstract void display();
	void run()
	{
		System.out.println("hi");
	}
	
	void message()
	{
		System.out.println("hello");
	}
	
}

class Demo2 extends Demo
{
	
	
	void display()
	{
		System.out.println("Welcome");
	}
	
	
}
public class UsingAbstractClass {

	public static void main(String[] args) {
		
		Demo2 obj=new Demo2();
		obj.display();
		obj.message();
		obj.run();
		
//		Demo ref=new Demo2();
//		ref.display();
		
		

	}

}
