package FinalKeywordandAbstraction;

//class Test5B
//{
//	final int add(int x,int y)
//	{
//		return x+y;
//	}
//}
//
//class Test5C extends Test5B
//{
//	int add(int x,int y)
//	{
//		return x+y;
//	}
//}
//
//public class UsingFinalForMethod {
//
//	public static void main(String[] args) {
//		
//		Test5C obj=new Test5C();
//	System.out.println(obj.add(4, 12));	
//		
//		
//
//	}
//
//}
