package PoylMorphismConcepts;

class Test3
{
	void display()
	{
		System.out.println("hello");
	}
	
	int display(int x)
	{
		return x+7;
	}
}


public class MethodOverloadingEx {

	public static void main(String[] args) {
		
		Test3 obj=new Test3();
		obj.display();
	System.out.println(obj.display(5));	
		
		
		

	}

}
