package PublicExample2;

import PublicExample1.Public1;

public class Public3 extends Public1 {

	public static void main(String[] args) {
		
		
		Public3 obj=new Public3();
		obj.display();

	}

}
