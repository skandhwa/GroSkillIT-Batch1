package TakingInputFromUser;

import java.util.Scanner;

class C16
{
	void display()
	{
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter the first number");
	int x=sc.nextInt();
	System.out.println("Enter the second number");
	
	int y=sc.nextInt();
	
	int z=x+y;
	
	System.out.println("The sum is "+z);
}
	
	void test()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the first number as floating point");
		float x=sc.nextFloat();
		System.out.println("Enter the second number as floating point");
		
		float y=sc.nextFloat();
		
		float z=x+y;
		
		System.out.println("The sum is "+z);
	}
	
}


public class MyFirstInput {

	public static void main(String[] args) {
		
		C16 obj=new C16();
		//obj.display();
		obj.test();
		
		
		
		
		
		
		
		
		
		

	}

}
