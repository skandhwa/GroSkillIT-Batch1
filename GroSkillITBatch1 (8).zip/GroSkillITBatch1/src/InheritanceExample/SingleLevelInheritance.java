package InheritanceExample;

class T8
{
	void display()
	{
		System.out.println("hello");
	}
}

class T9 extends T8
{
	void test()
	{
		System.out.println("Hi");
	}
}

public class SingleLevelInheritance {

	public static void main(String[] args) {
		
		T9 obj=new T9();
		obj.display();
		obj.test();
		
		
		

	}

}
