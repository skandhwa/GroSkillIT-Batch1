package MyPractice;

public class LogicalAndOperatorEx2 {

	public static void main(String[] args) {
		
		int a=10;
		int b=20;
		int c=30;
		
		if (!(a>=c || b<=c || c<=a))
		{
			System.out.println("hello");
		}
		else
		{
			System.out.println("Hi");
		}
		

	}

}
