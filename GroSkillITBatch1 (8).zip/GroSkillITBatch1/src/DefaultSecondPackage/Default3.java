//package DefaultSecondPackage;
//
////import DefaultEx1.C14;
//
//public class Default3 extends C14 {
//
//	public static void main(String[] args) {
//		
//		//C14 obj=new C14();
//		//obj.display();
//		
//
//	}
//
//}
