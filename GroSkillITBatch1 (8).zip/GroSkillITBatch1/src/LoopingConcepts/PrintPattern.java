package LoopingConcepts;

public class PrintPattern {

	public static void main(String[] args) {
		
		int r=4;
		for(int i=0;i<r;i++)////i=2,2<4
		{
			for(int j=0;j<=i;j++)//j=0,0<=2//j=1,1<=2//j=2,2<=2//j=3,3<=2
			{
				System.out.print("* ");//* * *
			}
			System.out.println();
		}
		

	}

}
