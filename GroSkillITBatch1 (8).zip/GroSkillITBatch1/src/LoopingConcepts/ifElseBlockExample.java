package LoopingConcepts;

public class ifElseBlockExample {

	public static void main(String[] args) {
		
		int a=20;
		int b=30;
		
		if(a>b)
		{
			System.out.println("a is max");
		}
		else
		{
			System.out.println("b is max");
		}
		

	}

}
