package InterfaceExamples;

//public interface Serializable
//{
//	
//}

public class MarkerInterfaceExample {

	public static void main(String[] args) {
		
		
		

	}

}
