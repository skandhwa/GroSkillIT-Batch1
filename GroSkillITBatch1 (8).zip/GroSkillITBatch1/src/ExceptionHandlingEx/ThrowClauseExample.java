package ExceptionHandlingEx;

class Test8
{
	public static void checkAge(int a)
	{
		if(a<18)
		{
			throw new ArithmeticException("You are not elligible to vote");
		}
		else
		{
			System.out.println("You are elligible Please caste your vote");
		}
	}
}



public class ThrowClauseExample {

	public static void main(String[] args) {
		
		
		Test8.checkAge(13);
		
		

	}

}
