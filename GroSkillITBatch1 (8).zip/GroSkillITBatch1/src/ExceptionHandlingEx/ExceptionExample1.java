package ExceptionHandlingEx;

public class ExceptionExample1 {

	public static void main(String[] args) {
		
		try
		{
		int z=20/0;
		System.out.println(z);
		}
		catch(ArithmeticException e)
		{
			System.out.println("caught with "+e);
		}
		
		
		
		
		int a=20;
		int b=30;
		int c=a+b;
		System.out.println(c);
		
		
		

	}

}
