package ExceptionHandlingEx;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

class Test10
{
	public static void method(boolean flag) throws FileNotFoundException 
	{
		if(flag==true)
		{
		
		FileReader f=new FileReader("D:\\FirstName9.txt");
		BufferedReader fp=new BufferedReader(f);
		System.out.println("You are elligible to read data from file");
		
		}
		
		
		else
		{
			System.out.println("You are not elligible to access the file");
			throw new FileNotFoundException();
		}
		
	}
}




public class ThrowClauseforCheckedException {

	public static void main(String[] args) throws FileNotFoundException {
		
		
		Test10.method(true);
		
		

	}

}
