package ArrayExamples;

public class FindOddElementsfromarray {

	public static void main(String[] args) {
		
		int a[]= {1,2,3,4,5,6};
		System.out.println("Elements from even position are");
		for(int i=1;i<a.length;i=i+2)
		{
			System.out.println(a[i]);
		}
		
		System.out.println("Printing odd numbers");
		for(int i=0;i<a.length;i++)
		{
			if(a[i]%2!=0)
			{
				System.out.println(a[i]);
			}
		}
		
		System.out.println("Printing even numbers");
		for(int i=0;i<a.length;i++)
		{
			if(a[i]%2==0)
			{
				System.out.println(a[i]);
			}
		}
		
		
		
		

	}

}
