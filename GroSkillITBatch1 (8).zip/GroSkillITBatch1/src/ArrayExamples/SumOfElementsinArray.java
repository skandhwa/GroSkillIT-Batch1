package ArrayExamples;

public class SumOfElementsinArray {

	public static void main(String[] args) {
		
		int a[]= {12,45,32,54};
		int sum=0;
		
		for(int i=0;i<a.length;i++)//i=0,0<4//i=1,1<4
		{
			sum=sum+a[i];///sum=0+12=12//sum=12+45=57//sum=57+32=89//sum=89+54
		}
		
		System.out.println("Sum of all elements are "+sum);
		
		
		

	}

}
