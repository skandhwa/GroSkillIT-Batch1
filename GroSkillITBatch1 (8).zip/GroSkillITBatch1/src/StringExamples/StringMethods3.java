package StringExamples;

public class StringMethods3 {

	public static void main(String[] args) {
		
		String str1="India";
		String str2="Republic";
		
	String str3=	str1.concat(str2);
	System.out.println(str3);
	
	String str4=str1+str2;
	System.out.println(str4);
	
//	String str5=null;
//	int x=str5.length();
//	System.out.println(x);
	
	String str6="";
	boolean z=str6.isEmpty();
	System.out.println("Is the String empty "+z);
	
	
		

	}

}
