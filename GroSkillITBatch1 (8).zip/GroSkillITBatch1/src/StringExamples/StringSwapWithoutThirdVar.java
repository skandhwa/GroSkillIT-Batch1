package StringExamples;

public class StringSwapWithoutThirdVar {

	public static void main(String[] args) {
		
		String str1="tom";
		String str2="ron";
		
		System.out.println("First String before reverse is "+str1);
		System.out.println("Second String before reverse is "+str2);
		
		str1=str1+str2;///str1=tomron
		
		str2=str1.substring(0,(str1.length()-str2.length()));///str2=
		str1=str1.substring(str2.length());
		
		System.out.println("First String after reverse is "+str1);
		System.out.println("Second String after reverse is "+str2);
		
		

	}

}
