package StringExamples;

public class StringMethods10 {

	public static void main(String[] args) {
		
		String str="India";
	char []ch=	str.toCharArray();
	
	
		
		

	}

}
