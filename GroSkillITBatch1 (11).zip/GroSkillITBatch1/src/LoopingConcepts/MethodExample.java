package LoopingConcepts;

class Employee
{
	void displayTest()
	{
		System.out.println("hello");
	}
}



public class MethodExample {

	public static void main(String[] args) {
		
		
		

	}

}
