package LoopingConcepts;

public class NestedIfElseLadder {

	public static void main(String[] args) {
		
		int a=20,b=30,c=40,d=25;
		if(a>b && a>c && a>d)
		{
			System.out.println("a is maximum");
		}
		else if(b>a && b>c && b>d)
		{
			System.out.println("b is maximum");
		}
		
		else if(c>a && c>b && c>d)
		{
			System.out.println("c is maximum");
		}
		else
		{
			System.out.println("d is maximum");
		}
		
		
		

	}

}
