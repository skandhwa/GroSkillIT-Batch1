package SetExamples;

import java.util.HashSet;
import java.util.Set;

public class HashSetMethods6 {

	public static void main(String[] args) {
		
		Set<String> s1=new HashSet<String>();
		s1.add("kiwi");
		s1.add("Orange");
		s1.add("apple");
		s1.add("grapes");
		s1.add("apple");
		
		
		String []arr=new String[s1.size()];
		
		s1.toArray(arr);
		
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		
		

	}

}
