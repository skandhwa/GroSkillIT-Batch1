package SetExamples;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class HashSetMethods5 {

	public static void main(String[] args) {
		
		Integer []a= {2,4,5,6,2,8,10,4};
		
		
		Set<Integer> s1=new LinkedHashSet<>(Arrays.asList(a));
		
		
		System.out.println(s1);
		
		
		

	}

}
