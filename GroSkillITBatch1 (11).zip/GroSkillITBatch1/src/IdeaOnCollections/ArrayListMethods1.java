package IdeaOnCollections;

import java.util.ArrayList;
import java.util.List;

public class ArrayListMethods1 {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(56);
		li.add(98);
		li.add(77);
		li.add(98);
		
		
		li.set(2, 99);
		
		for(Integer x:li)
		{
			System.out.println(x);
		}
		
		int x=li.size();
		System.out.println("The size of array list is "+x);
		
		li.set(3, 199);
		for(Integer y:li)
		{
			System.out.println(y);
		}

		int z=li.get(3);
		System.out.println("Element at third index is "+z);
		
		
		
	}

}
