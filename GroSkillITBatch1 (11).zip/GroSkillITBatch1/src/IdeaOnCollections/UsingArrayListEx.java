package IdeaOnCollections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class UsingArrayListEx {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(56);
		li.add(98);
		li.add(77);
		li.add(98);
		for(Integer x:li)
		{
			System.out.println(x);
		}
		
		Iterator itr=li.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		System.out.println(li);
		
		
		
		
		
//		List<String> li2=new ArrayList<String>();
//		li2.add("kiwi");
//		li2.add("mango");
//		li2.add("apple");
//		li2.add("orange");
//		
//		
		List<Object> li3=new ArrayList<Object>();
		li3.add("kiwi");
		li3.add(1234);
		li3.add(true);
		li3.add('A');
		li3.add(24213213213L);
		li3.add("ACBASDSAJ$%**&***99999");
//		
		
		
		
		

	}

}
