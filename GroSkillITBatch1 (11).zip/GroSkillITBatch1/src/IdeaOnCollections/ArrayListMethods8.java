package IdeaOnCollections;

import java.util.ArrayList;
import java.util.List;

public class ArrayListMethods8 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("melon");
		li.add("guava");
		li.add("banana");
		li.add("apple");
		li.add("papaya"); 
		
	int p=	li.indexOf("melon");
	System.out.println("Index of melon is "+p);
		
		int x=li.size();
		
		String []arr=new String[x];
		
//		li.toArray(arr);
//		
//		for(String y:arr)
//		{
//			System.out.println(y);
//		}
		System.out.println("Converting list to String");
		String value=li.toString();
		System.out.println(value);
		
		
		
	}

}
