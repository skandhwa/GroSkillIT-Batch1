package IdeaOnCollections;

import java.util.ArrayList;
import java.util.List;

public class ArrayListMethods7 {

	public static void main(String[] args) {
		List<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(56);
		li.add(98);
		li.add(77);
		li.add(98);
		
		li.replaceAll(a-> a*3);
		
		System.out.println(li);

	}

}
