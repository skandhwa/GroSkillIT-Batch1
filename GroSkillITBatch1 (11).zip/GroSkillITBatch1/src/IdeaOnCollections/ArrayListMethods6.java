package IdeaOnCollections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListMethods6 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("melon");
		li.add("guava");
		li.add("banana");
		li.add("apple");
		li.add("papaya");    
		
		li.replaceAll(a ->a.toUpperCase());
		System.out.println(li);
		
		li.replaceAll(b ->b.toLowerCase());
		System.out.println(li);
		
		
		
		List<String> li2=new ArrayList<String>();
		li2.add("melon");
		li2.add("guava");
		li2.add("kiwi");
		
		
	boolean flag=	li.containsAll(li2);
	System.out.println(flag);
	
	Collections.sort(li);
	System.out.println();
	System.out.println("After sorting elements are");
	System.out.println(li);
	
	
	
	
		
		
		
	}

}
