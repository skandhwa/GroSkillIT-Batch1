package IdeaOnCollections;

import java.util.LinkedList;
import java.util.List;

public class LinkedListExample1 {

	public static void main(String[] args) {
		
		List<Integer> li=new LinkedList<Integer>();
		
		li.add(34);
		li.add(56);
		li.add(314);
		li.add(156);
		
		for(Integer x:li)
		{
			System.out.println(x);
		}
		
		
		
		
		
		

	}

}
