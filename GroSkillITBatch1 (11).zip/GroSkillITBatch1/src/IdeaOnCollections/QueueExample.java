package IdeaOnCollections;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueExample {

	public static void main(String[] args) {
		
		Queue<String> q1=new PriorityQueue<String>();
		q1.add("Amit");
		q1.add("Rohan");
		q1.add("Mahesh");
		q1.add("Ramesh");
//		q1.add(32);
//		q1.add(true);
//		q1.add('A');
		
		for(String x:q1)
		{
			System.out.println(x);
		}
		
		q1.remove();
		System.out.println("After removing elements are");
		for(String y:q1)
		{
			System.out.println(y);
		}
		
		System.out.println("Head of queue is "+q1.element());
		System.out.println("peek of queue is "+q1.peek());
		
		q1.remove("Rohan");
		for(String z:q1)
		{
			System.out.println(z);
		}
		
		

	}

}
