package Practice4;

public class MyPractice1 {

	public static void main(String[] args) {
		
		
		

	}

}
