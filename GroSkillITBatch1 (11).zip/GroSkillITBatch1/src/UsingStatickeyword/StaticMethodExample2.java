package UsingStatickeyword;

class Calculation
{
	static int cube(int x)
	{
		return x*x*x;
	}
}


public class StaticMethodExample2 {

	public static void main(String[] args) {
		
	System.out.println("The cube of number is  "+Calculation.cube(9));	;
		
		
		

	}

}
