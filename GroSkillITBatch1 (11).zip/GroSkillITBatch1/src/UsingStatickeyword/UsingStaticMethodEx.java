package UsingStatickeyword;

class Student5
{
	int id;
	String name;
	static String collegename="KIIT";
	
	Student5(int i,String n)
	{
		id=i;
		name=n;
	}
	
	static void change()
	{
		collegename="ITER";
	}

	 void display()
	{
		System.out.println(id+"  "+name+" "+collegename);
	}
	}


public class UsingStaticMethodEx {

	public static void main(String[] args) {
		
		Student5.change();
		
		Student5 obj=new Student5(1234,"Tom");
		obj.display();
		Student5 obj1=new Student5(4234,"Harry");
		obj1.display();
	}

}
