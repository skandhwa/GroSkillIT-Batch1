package TakingInputFromUser;

import java.util.Scanner;

public class MenuDrivenCalculator {

	public static void main(String[] args) {
		
		char operator;
		double num1,num2,result;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Please choose an operator");
		operator =sc.next().charAt(0);
		
		System.out.println("Enter the first number");
		num1=sc.nextDouble();
		System.out.println("Enter the second number");
		num2=sc.nextDouble();
		
		switch(operator)
		{
		case '+':
			 result=num1+num2;
			 System.out.println("The addition of two numbers are "+result);			 
			 break;
		case '-':
			 result=num1-num2;
			 System.out.println("The subtraction of two numbers are "+result);			 
			 break;	 
			 
		case '*':
			 result=num1*num2;
			 System.out.println("The product of two numbers are "+result);			 
			 break;	 	 
		case '/':
			 result=num1/num2;
			 System.out.println("The division of two numbers are "+result);			 
			 break;	
			 
		default:
			System.out.println("You have entered an invalid input");
		
		
		}
		
		
		
		

	}

}
