package StringExamples;

public class RevrseofString {

	public static void main(String[] args) {
		
		String str="tat";
		
		String str1=str;
		String revstr="";
		
		
		for(int i=0;i<str.length();i++)///i=0,0<6
		{
			
			revstr=str.charAt(i)+revstr;//revstr=n+
		}
		
		System.out.println(revstr);
		
		if(str1.equals(revstr))
		{
			System.out.println("String is palindrome");
		}
		else
		{
			System.out.println("String is not palindrome");
		}
		
		
		
		

	}

}
