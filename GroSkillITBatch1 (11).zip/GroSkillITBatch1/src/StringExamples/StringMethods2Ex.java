package StringExamples;

public class StringMethods2Ex {

	public static void main(String[] args) {
		
//		String str="India is a vast country";
//		boolean x=str.contains(" ");
//		System.out.println(x);
		
		String str1="adam";
		String str2="Adam";
	boolean y=	str1.equals(str2);
	System.out.println(y);
	
	boolean z=str1.equalsIgnoreCase(str2);
	System.out.println(z);
	
     
		
		
		

	}

}