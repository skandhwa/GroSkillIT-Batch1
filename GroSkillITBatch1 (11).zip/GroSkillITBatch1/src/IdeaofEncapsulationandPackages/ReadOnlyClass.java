package IdeaofEncapsulationandPackages;

class Bank13
{
	private int AccNo=12345678;
	private String name;
	
	
	public int getAccNo() {
		return AccNo;
	}
	
	public String getName() {
		return name;
	}
	
	
}



public class ReadOnlyClass {

	public static void main(String[] args) {
		
		Bank13 obj=new Bank13();
	System.out.println(obj.getAccNo());	
		

	}

}
