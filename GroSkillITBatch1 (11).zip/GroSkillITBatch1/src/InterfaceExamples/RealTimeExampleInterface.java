package InterfaceExamples;

interface Bank
{
	float ROI();
}

class SBI implements Bank
{
	public float ROI()
		{
			return 8.5f;
		}
}
	
class PNB implements Bank
{
	public float ROI()
		{
			return 9.5f;
		}
}
	

public class RealTimeExampleInterface {

	public static void main(String[] args) {
		
		Bank ref=new SBI();
	System.out.println(ref.ROI());	
		
	Bank ref1=new PNB();
	System.out.println(ref1.ROI());	

	}

}
