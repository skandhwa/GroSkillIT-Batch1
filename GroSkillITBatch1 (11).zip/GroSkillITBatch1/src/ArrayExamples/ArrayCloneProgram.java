package ArrayExamples;

public class ArrayCloneProgram {

	public static void main(String[] args) {
		
		int a[]= {33,43,12,56};
		System.out.println("Printing the original array");
		for(int x:a)
		{
			System.out.println(x);
		}
		
		System.out.println("Printing array clone");
		int carray[]=a.clone();
		for(int y:carray)
		
		{
			System.out.println(y);
		}
		

	}

}
