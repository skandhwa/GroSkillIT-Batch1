package ArrayExamples;

class ThirdLargestNumber
{
	public static int getThirdLargest(int []a,int n)
	{
		
		
		for(int i=0;i<n;i++)//i=0,0<4//i=1,1<4//i=2,2<4//i=3,3<4//i=4,4<4
		{
			for(int j=i+1;j<n;j++)//
			{
				 if(a[i]>a[j])//a[2]>a[3]
				 {
					 int t=a[i];
					 a[i]=a[j];
					 a[j]=t;
				 }
			}
			
		}
		return a[n-3];
		
		//return a[7-1];
			
			
			
	}
}



public class ThirdLargestNumberFromArray {

	public static void main(String[] args) {
		
		int []a= {23,12,45,5,76,14,65,32,13,99};
		
		System.out.println("Third largest "+ThirdLargestNumber.getThirdLargest(a,6));
		//System.out.println("smallest "+ThirdLargestNumber.getThirdLargest(a,6));
	

	}

}
