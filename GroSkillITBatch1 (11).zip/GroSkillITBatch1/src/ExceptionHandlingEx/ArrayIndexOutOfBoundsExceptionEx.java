package ExceptionHandlingEx;

public class ArrayIndexOutOfBoundsExceptionEx {

	public static void main(String[] args) {
		
		
		try
		{
		int a[]= new int []{10,20,30,40,50};
		
		System.out.println(a[6]);
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("caught with "+e);
		}
		
		int z=20;
		int b=30;
		int c=z+b;
		System.out.println(c);

	}

}
