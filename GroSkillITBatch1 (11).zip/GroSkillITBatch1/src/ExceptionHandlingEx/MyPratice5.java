package ExceptionHandlingEx;

public class MyPratice5 {

	public static void main(String[] args) throws InterruptedException {
	
		
		Thread.sleep(5000);

	}

}
