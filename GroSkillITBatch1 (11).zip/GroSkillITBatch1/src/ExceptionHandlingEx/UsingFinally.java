package ExceptionHandlingEx;

public class UsingFinally {

	public static void main(String[] args) {
		
		try
		{
		int a=10;
		int b=a/0;
		System.out.println(b);
		}
		
		
//		catch(Exception e)
//		{
//			System.out.println("Exception occured with "+e);
//		}
		
		finally
		{
			int z=20;
			int f=30;
			int c=z+f;
			System.out.println(c);
		}
		
		

	}

}
