package FinalKeywordandAbstraction;

abstract class Shape
{
	abstract void draw();
	void display()
	{
		System.out.println("hello");
	}
	
	void test()
	{
		System.out.println("hi");
	}
	
	
	void message()
	{
		System.out.println("my new");
	}
}



class Circle extends Shape
{
	void draw()
	{
		System.out.println("Drawing circle");
	}
}


public class AbstractclassExample2 {

	public static void main(String[] args) {
		
		Circle obj=new Circle();
		obj.draw();
		
		
		Shape ref=new Circle();
		ref.draw();
		

	}

}
