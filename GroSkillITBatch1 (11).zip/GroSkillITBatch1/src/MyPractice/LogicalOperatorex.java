package MyPractice;

public class LogicalOperatorex {

	public static void main(String[] args) {
		
		int a=10;
		int b=20;
		int c=30;
		
		boolean flag= (a<=c && c>=b && b<=a);
		System.out.println(flag);
		

	}

}
